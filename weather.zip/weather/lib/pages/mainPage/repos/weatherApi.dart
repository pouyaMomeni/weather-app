// import 'package:flutter/material.dart';
// import 'package:http/http.dart';

// class WeatherApiFetch {
//   Future<Response?> WeatherFecth() {

//   }
// }
