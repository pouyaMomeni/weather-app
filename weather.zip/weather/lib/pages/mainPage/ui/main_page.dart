import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:weatherr/constants/color.dart';
import 'package:weatherr/pages/mainPage/bloc/mian_page_bloc.dart';
import 'package:weatherr/widget/filter.dart';

class MainPage extends StatefulWidget {
  MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  late double _deviceWidth;

  late double _deviceHeight;

  final MianPageBloc mianPageBloc = MianPageBloc();
  @override
  void initState() {
    mianPageBloc.add(MainPageInitialFetchEvent());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _deviceWidth = MediaQuery.of(context).size.width;
    _deviceHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarBrightness: Brightness.dark,
        ),
      ),
      body: BlocConsumer<MianPageBloc, MianPageState>(
        bloc: mianPageBloc,
        listenWhen: (previous, current) => current is MainPageActionState,
        buildWhen: (previous, current) => current is! MainPageActionState,
        listener: (context, state) {
          // TODO: implement listener
        },
        builder: (context, state) {
          switch (state.runtimeType) {
            case MainPageLoadingState:
              return const Center(
                child: CircularProgressIndicator(
                  color: AppColor.white,
                ),
              );
            case MainPageSuccessfullState:
              return Padding(
                padding:
                    const EdgeInsets.fromLTRB(40, kToolbarHeight * 1.2, 40, 20),
                child: SizedBox(
                  height: _deviceHeight,
                  child: Stack(
                    children: [
                      const FilterWidget(),
                      SizedBox(
                        width: _deviceWidth,
                        height: _deviceHeight,
                        child: Column(
                          children: [
                            Container(
                              alignment: Alignment.topLeft,
                              child: const Row(
                                children: [
                                  Icon(
                                    Icons.location_on,
                                    color: AppColor.white,
                                    size: 16,
                                  ),
                                  Text(
                                    " Mazandran , Babol",
                                    style: TextStyle(
                                      color: AppColor.white,
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: _deviceHeight * 0.005,
                            ),
                            Container(
                              alignment: Alignment.topLeft,
                              child: const Text(
                                'Good Morning',
                                style: TextStyle(
                                  color: AppColor.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25,
                                ),
                              ),
                            ),
                            Image.asset('assets/images/1.png'),
                            Container(
                              alignment: Alignment.center,
                              child: const Text(
                                '21 C',
                                style: TextStyle(
                                  color: AppColor.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 30,
                                ),
                              ),
                            ),
                            Container(
                              alignment: Alignment.center,
                              child: const Text(
                                'Thunder Storm',
                                style: TextStyle(
                                  color: AppColor.white,
                                  fontSize: 25,
                                ),
                              ),
                            ),
                            SizedBox(
                              height: _deviceHeight * 0.005,
                            ),
                            Container(
                              alignment: Alignment.center,
                              child: const Text(
                                'Fridat 16 . 5:49',
                                style: TextStyle(
                                  color: AppColor.white,
                                  fontSize: 15,
                                ),
                              ),
                            ),
                            SizedBox(
                              height: _deviceHeight * 0.08,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: _deviceWidth * 0.15,
                                      height: _deviceHeight * 0.07,
                                      decoration: const BoxDecoration(
                                        image: DecorationImage(
                                          image: AssetImage(
                                            'assets/images/11.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    const Column(
                                      children: [
                                        Text(
                                          'Sunrise',
                                          style: TextStyle(
                                              color: AppColor.thirdColor),
                                        ),
                                        Text(
                                          '5:32 AM',
                                          style:
                                              TextStyle(color: AppColor.white),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Container(
                                      width: _deviceWidth * 0.15,
                                      height: _deviceHeight * 0.07,
                                      decoration: const BoxDecoration(
                                        image: DecorationImage(
                                          image: AssetImage(
                                            'assets/images/12.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    const Column(
                                      children: [
                                        Text(
                                          'Sunset',
                                          style: TextStyle(
                                              color: AppColor.fourthColor),
                                        ),
                                        Text(
                                          '6:34 PM',
                                          style:
                                              TextStyle(color: AppColor.white),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ],
                            ),
                            const Divider(
                              thickness: 0.5,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: _deviceWidth * 0.15,
                                      height: _deviceHeight * 0.07,
                                      decoration: const BoxDecoration(
                                        image: DecorationImage(
                                          image: AssetImage(
                                            'assets/images/13.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    const Column(
                                      children: [
                                        Text(
                                          'Temp Max',
                                          style: TextStyle(
                                            color: AppColor.thirdColor,
                                          ),
                                        ),
                                        Text(
                                          '12 C',
                                          style: TextStyle(
                                            color: AppColor.white,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Container(
                                      width: _deviceWidth * 0.15,
                                      height: _deviceHeight * 0.07,
                                      decoration: const BoxDecoration(
                                        image: DecorationImage(
                                          image: AssetImage(
                                            'assets/images/14.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    const Column(
                                      children: [
                                        Text(
                                          'Temp Min',
                                          style: TextStyle(
                                            color: AppColor.fourthColor,
                                          ),
                                        ),
                                        Text(
                                          '8 C',
                                          style: TextStyle(
                                            color: AppColor.white,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );

            default:
              return Center(child: Text('ssssssssssssss'));
          }
        },
      ),
    );
  }
}
