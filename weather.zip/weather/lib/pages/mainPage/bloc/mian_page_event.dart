part of 'mian_page_bloc.dart';

@immutable
sealed class MianPageEvent {}

class MainPageInitialFetchEvent extends MianPageEvent {}
